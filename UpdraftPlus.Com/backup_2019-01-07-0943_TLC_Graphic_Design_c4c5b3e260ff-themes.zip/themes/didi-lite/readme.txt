Didi Lite is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

Didi Lite WordPress Theme is derived from Underscores WordPress Theme, Copyright 2013 Automattic, Inc.
Underscores WordPress Theme is distributed under the terms of the GNU GPL

Ginger WordPress Theme bundles the following third-party resources:

Genericons icon font, Copyright 2013 Automattic
Genericons are licensed under the terms of the GNU GPL, Version 2 (or later)
Source: http://www.genericons.com

Google Fonts
Inconsolata	SIL Open Font License, 1.1
Inconsolata-Regular.ttf: Copyright 2006 The Inconsolata Project Authors
Inconsolata-Bold.ttf: Copyright 2006 The Inconsolata Project Authors

Josefin Sans	SIL Open Font License, 1.1
JosefinSans-Thin.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-ThinItalic.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-Light.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-LightItalic.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-Regular.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-Italic.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-SemiBold.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-SemiBoldItalic.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-Bold.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
JosefinSans-BoldItalic.ttf: Copyright (c) 2010 by Typemade (hi@typemade.mx). All rights reserved.
Source: https://www.google.com/fonts

Normalize: /*! normalize.css v3.0.2 | MIT License | git.io/normalize */

Images used in the screenshot are distributed under the terms of the Creative Commons Zero: https://unsplash.com/






