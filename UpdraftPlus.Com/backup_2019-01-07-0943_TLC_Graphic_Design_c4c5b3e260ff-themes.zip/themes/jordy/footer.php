<footer id="colophon" class="footer">
	<div class="footer__wrapper">
		<?php do_action( 'xtheme/h/social_menu' ); ?>
		<div class="copyright">
			<?php
			Xtheme_Club\copyright();
			Xtheme_Club\go_to_top();
			?>
		</div>
	</div>
</footer>
