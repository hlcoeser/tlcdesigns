<header id="masthead" class="header">
	<?php get_template_part( 'template-parts/header/top' ); ?>
	<div class="header__wrapper">
		<?php
		get_template_part( 'template-parts/header/site', 'branding' );
		get_template_part( 'template-parts/header/navigation', 'top' );
		?>
	</div>
</header>
